# -*- coding: utf-8 -*-
# Part of BrowseInfo. See LICENSE file for full copyright and licensing details.


from . import res_company
from . import res_setting_config
from . import sale_order
from . import purchase_order
from . import account_move
from . import stock_move
from . import stock_rule
from . import mrp